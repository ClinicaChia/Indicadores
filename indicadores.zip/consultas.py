from operator import index
import mysql.connector
import pandas as pd
def consulta(sql):
       
       mydb = mysql.connector.connect(
       host="localhost",
       user="root",
       password="Clinica2030*",
       database="indicadores_ok")
       

       query = mydb.cursor()
       
       query.execute(sql)
       
       vals=query.fetchall()
       
       return vals

def get_values(lista):

    values=[]
    for i in lista:
        values.append(i[0])
    return values

def setConsulta(sede,especialidad,indicador):
    txt="SELECT valores.valor FROM  valores inner join meses on meses.id=valores.idmes inner join years on valores.idyear=years.id inner join sedes on valores.idsede=sedes.id inner join indicadores on valores.idindicador=indicadores.id inner join especialidades on valores.idespecialidad=especialidades.id WHERE sedes.sede = '{}' AND especialidades.nombre = '{}' AND years.year = if(MONTH(NOW())-1=0,YEAR(NOW())-1,YEAR(NOW())) AND meses.id = if(MONTH(NOW())-1=0,12,MONTH(NOW())-1) AND indicadores.id = {}"
    sql=txt.format(sede,especialidad,indicador)
    return sql

sedes=consulta('SELECT sede FROM sedes')

sedes = get_values(sedes)

especilidades=consulta('SELECT nombre FROM especialidades')

especilidades = get_values(especilidades)

indicadores = consulta('SELECT nombre_indicador FROM indicadores')

indicadores = get_values(indicadores)


tabla = pd.DataFrame(columns=['sede','Especialidad','Indicador','Consulta'])


print(setConsulta("mosquera","medicina general","1"))
n=1
for sede in sedes:
    for especialidad in especilidades:
        for indicador in range(1,len(indicadores)+1):
            temp= pd.DataFrame([[sede,especialidad,indicadores[indicador-1],setConsulta(sede,especialidad,indicador)]],columns=['sede','Especialidad','Indicador','Consulta'])
            
            tabla=pd.concat([tabla,temp])
            

tabla.to_excel("consultas.xlsx") 
